# Sharing & Usage

**Classification:** TLP:CLEAR. Re-classify before distribution if your program requires a stricter marking.

**Intended use:** defensive detection, threat hunting, and incident response against TernDoor / UAT-9244.

**Indicators and signatures** are provided for blue-team operational use. Suricata/Snort SIDs use a private example range (9000001+); renumber to fit your sensor allocation before deployment.

**Samples and memory images are not included** in this repository and should not be committed to it (see `.gitignore`).
